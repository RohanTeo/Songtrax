import React from 'react';
import "./style.css";

function Footer() {
  return (
    <footer className="page-footer">
      {/* Footer content goes here */}
      <div>
        
      </div>
    </footer>
  );
}

export default Footer;
