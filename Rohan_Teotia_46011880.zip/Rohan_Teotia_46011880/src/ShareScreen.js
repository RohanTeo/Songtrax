import React from 'react';
import "./style.css";

// Define the LocationToggle functional component
function LocationToggle({ locationName, shared }) {
  return (
    <div className="toggle-row-container">
      <div className="location-name-label">
        <h4>{locationName}</h4>
      </div>
      <div className="sequence-row-container">
        {/* Render a "Shared" button. Apply 'toggle-selected' class if shared is true. */}
        <button className={shared ? 'toggle-selected' : 'toggle'}>
          Shared
        </button>
        {/* Render a "Not Shared" button. Apply 'toggle-selected' class if shared is false. */}
        <button className={!shared ? 'toggle-selected' : 'toggle'}>
          Not Shared
        </button>
      </div>
    </div>
  );
}

// Define the ShareScreen functional component
function ShareScreen() {
  // Render the main content of the ShareScreen
  return (
    <main>
      <h2 className="title">Share This Sample</h2>

      <div className="card">
        <div className="song-details">
          <h3>Sample Name</h3>
          <p>Date Created</p>
        </div>
        <div className="buttons">
          <a href="#" className="bright-button">Preview</a>
        </div>
      </div>

      {/* Render LocationToggle components */}
      <LocationToggle locationName="UQ Lakes" shared={true} />
      <LocationToggle locationName="Wordies" shared={true} />
      <LocationToggle locationName="Great Court" shared={true} />
      {/* You can add more LocationToggle components as needed */}
    </main>
  );
}

// Export the ShareScreen component as the default export
export default ShareScreen;
