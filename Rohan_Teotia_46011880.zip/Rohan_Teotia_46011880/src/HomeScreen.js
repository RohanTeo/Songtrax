import { NavLink } from 'react-router-dom';
import React from 'react';
import "./style.css";

// Define the SongCard functional component
function SongCard({ songName, dateCreated }) {
  // Render a card with song details
  return (
    <section className="sample">
      <div className="card">
        <div className="song-details">
          <h3>{songName}</h3>
          <p>{dateCreated}</p>
        </div>
        <div className="button-group-container">
          {/* Replace the <a> tag for the Share button with <NavLink> */}
          <NavLink to="/sharescreen" className="button">Share</NavLink>
          <a href="#" className="button">Preview</a>
          <a href="#" className="bright-button">Edit</a>
        </div>
      </div>
    </section>
  );
}

// Define the HomeScreen functional component
function HomeScreen() {
  // Render the main content of the HomeScreen
  return (
    <main>
      <h2 className="title">Your Song Examples</h2>

      <div className="create-card">
        {/* Replace the <a> tag with <NavLink> */}
        <NavLink to="/createSample" className="bright-button">Create Sample</NavLink>
      </div>

      {/* Render a SongCard component with default songName and dateCreated */}
      <SongCard songName="Song Name" dateCreated="Date Created" />

      <div className="create-card">
        {/* Replace the <a> tag with <NavLink> */}
        <NavLink to="/createSample" className="bright-button">Create Sample</NavLink>
      </div>
    </main>
  );
}


// Export the HomeScreen component as the default export
export default HomeScreen;

