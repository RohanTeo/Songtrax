// Import necessary modules and components
import React from 'react';
import logo from './logo.svg';
import { BrowserRouter as Router, Route, Routes, NavLink } from 'react-router-dom';
import Header from './Header'; // Import the Header component
import CreateSample from './CreateSample'; // Import the CreateSample component
import HomeScreen from './HomeScreen'; // Import the HomeScreen component
import ShareScreen from './ShareScreen'; // Import the ShareScreen component
import Footer from './Footer.js';
import "./style.css";

// Define the main application component
function App() {
  return (
    // Use React Router to set up routing for the application
    <Router>
      <div className="App">
        <Header /> {/* Render the Header component */}



        <Routes>
          {/* Define routes for different pages/components */}
          <Route path="/createSample" element={<CreateSample />} />
          <Route path="/homescreen" element={<HomeScreen />} />
          <Route path="/sharescreen" element={<ShareScreen />} />
          <Route path="/" element ={<HomeScreen />} />
        </Routes>

        {/* You can include a Footer component here if needed */}
        <Footer>

        </Footer>
      </div>
    </Router>
  );
}

// Export the App component as the default export
export default App;
