import React, { useState } from 'react';
import "./style.css";

function ToggleButton({ isActive, onClick }) {
  const buttonClass = isActive ? 'toggle-selected' : 'toggle';

  return (
    <button onClick={onClick} className={buttonClass}></button>
  );
}

function ToggleRow({ label, activeButtons, setActiveButtons }) {
  return (
    <div className="toggle-row-container">
      <div className="row-label">
        <h4>{label}</h4>
      </div>
      <div className="sequence-row-container">
        {Array.from({ length: 16 }).map((_, index) => (
          <ToggleButton
            key={index}
            isActive={activeButtons.includes(index)}
            onClick={() => {
              if (activeButtons.includes(index)) {
                setActiveButtons(prev => prev.filter(i => i !== index));
              } else {
                setActiveButtons(prev => [...prev, index]);
              }
            }}
          />
        ))}
      </div>
    </div>
  );
}

function CreateSample() {
  const [activeInstrument, setActiveInstrument] = useState(null);
  const [activeB, setActiveB] = useState([]);
  const [activeA, setActiveA] = useState([]);
  const [activeG, setActiveG] = useState([]);
  const [activeF, setActiveF] = useState([]);
  const [activeE, setActiveE] = useState([]);
  const [activeD, setActiveD] = useState([]);
  const [activeC, setActiveC] = useState([]);

  return (
    <main>
        <h2 className="title">Edit Sample:</h2>
        <form className="card edit-card">
            <input type="text" placeholder="First Song" />
            <div className="button-group-container">
                <button type="button" className="button">Preview</button>
                <button type="button" className="bright-button">Save</button>
            </div>
        </form>

        <div className="toggle-row-container">
            <div className="row-label">
                <h4>Type</h4>
            </div>
            <div className="sequence-row-container">
                {['Piano', 'French Horn', 'Guitar', 'Drums'].map(instrument => (
                    <button 
                        key={instrument}
                        className={instrument === activeInstrument ? 'toggle-selected' : 'toggle'}
                        onClick={() => setActiveInstrument(instrument)}
                    >
                        {instrument}
                    </button>
                ))}
            </div>
        </div>



      <ToggleRow label="B" activeButtons={activeB} setActiveButtons={setActiveB} />
      <ToggleRow label="A" activeButtons={activeA} setActiveButtons={setActiveA} />
      <ToggleRow label="G" activeButtons={activeG} setActiveButtons={setActiveG} />
      <ToggleRow label="F" activeButtons={activeF} setActiveButtons={setActiveF} />
      <ToggleRow label="E" activeButtons={activeE} setActiveButtons={setActiveE} />
      <ToggleRow label="D" activeButtons={activeD} setActiveButtons={setActiveD} />
      <ToggleRow label="C" activeButtons={activeC} setActiveButtons={setActiveC} />
    </main>
  );
}

export default CreateSample;
