import React from 'react';
import "./style.css";

// Define the Header functional component
function Header() {
  // Render the content of the header
  return (
    <header className="page-header">
      <div className="header-logo">
        <h2>
          <a href="/" className="header-icon-link">SongTrax</a>
        </h2>
      </div>
      <div className="header-app-description">
        <span>Create & Share Samples, Listen in Mobile App!</span>
      </div>
    </header>
  );
}

// Export the Header component as the default export
export default Header;
